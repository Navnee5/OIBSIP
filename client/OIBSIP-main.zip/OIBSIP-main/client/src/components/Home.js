
const Home =()=>{
    return(
        <>
        <section className="corousel" ></section>
        <section className='bestPrize'>
            <div className="pizzaImage&tomato"></div>
            <div className="textwithfeature"></div>
        </section>
        <section className="3imgSectionwithText"></section>
        <section className="only3img"></section>
        <section className="categoryWithcardscouresl"></section>
        <section className="1img"></section>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>

        </>
    )
}

export default Home