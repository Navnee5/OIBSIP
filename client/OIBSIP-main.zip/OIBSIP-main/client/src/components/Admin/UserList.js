
const UserList = ()=>{
    return(
        <>
            <h1>User List</h1>
        </>
    )
}
export default UserList