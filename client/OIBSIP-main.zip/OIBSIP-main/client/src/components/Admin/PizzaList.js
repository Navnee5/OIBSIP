
const PizzaList = ()=>{
    return(
        <>
            <h1>Pizza List</h1>
        </>
    )
}
export default PizzaList