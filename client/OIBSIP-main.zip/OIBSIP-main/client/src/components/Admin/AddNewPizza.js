
const Addnewpizza = ()=>{
    return(
        <>
            <h1>Add New Pizza List</h1>
        </>
    )
}
export default Addnewpizza