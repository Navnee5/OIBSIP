import React from 'react'

const OrderList = () => {
  return (
    <>
    <h1>OrderList</h1>
    </>
  )
}

export default OrderList