import { Spinner } from "react-bootstrap"

const Loader =()=>{
    return <Spinner animation="border" varient="info"/>
}
    
export default Loader